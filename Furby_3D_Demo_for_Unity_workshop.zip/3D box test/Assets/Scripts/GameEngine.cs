﻿using UnityEngine;
using System.Collections;

public class GameEngine : MonoBehaviour {

	public GameObject rotationObject;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {

		// check for quit
		if (Input.GetKeyUp (KeyCode.Escape)) {
			// escape
			Application.Quit ();
		}

		/*
		//if (Input.deviceOrientation != DeviceOrientation.Unknown) {
			Physics.gravity = new Vector3 (
				rotationObject.transform.rotation.x  * gravity_multiplier
				Input.acceleration.normalized.x * gravity_multiplier, 
				Input.acceleration.normalized.y * gravity_multiplier,
				rotationObject);
		//}
	*/
	}
}
