﻿/*
check out this page
http://www.sc0ttgames.com/?p=293

*/

using UnityEngine;
using System.Collections;

public class MagnetButton : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
